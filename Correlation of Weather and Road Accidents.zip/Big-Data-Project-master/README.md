# Big-Data-Project
Analyzed the effect of weather, mainly precipitation, on the number of accidents occurring daily, for the span of five years, in New Jersey.
Generated and Profiled the smaller datasets from the two large data sets NCDC and New Jersey State Police, using Hadoop Map Reduce. 
Deduced the correlation using the comparative analysis between the average number of accidents occurred when there was zero or some precipitation, using HIVE.
Technologies Used: Java, Map-Reduce, Hive
